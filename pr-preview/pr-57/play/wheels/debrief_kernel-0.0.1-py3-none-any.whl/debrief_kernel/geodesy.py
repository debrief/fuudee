"""Geodesic geometry on WGS84 (SUB-03).

All measurement is geodesic on the WGS84 ellipsoid, independent of the
display projection, using Karney's algorithms (geographiclib). Positions are
(longitude, latitude) in decimal degrees, matching GeoJSON order. Bearings are
true, clockwise from north, in [0, 360).
"""

from __future__ import annotations

import math
from bisect import bisect_left, bisect_right
from collections.abc import Sequence
from dataclasses import dataclass

from geographiclib.geodesic import Geodesic
from geographiclib.geodesicline import GeodesicLine

from debrief_kernel.time import parse_utc
from debrief_kernel.units import Quantity, normalise_bearing
from debrief_schemas.generated import debrief as schema

WGS84 = Geodesic.WGS84
_INVERSE = Geodesic.DISTANCE | Geodesic.AZIMUTH


@dataclass(frozen=True, slots=True)
class Position:
    longitude: float
    latitude: float


def range_bearing(origin: Position, target: Position) -> tuple[Quantity, Quantity]:
    """Geodesic range in metres and initial true bearing in degrees from origin to target."""
    line = WGS84.Inverse(
        origin.latitude, origin.longitude, target.latitude, target.longitude, _INVERSE
    )
    return Quantity(line["s12"], "m"), Quantity(normalise_bearing(line["azi1"]), "deg")


def range_between(a: Position, b: Position) -> Quantity:
    return Quantity(_range_m(a, b), "m")


def _range_m(a: Position, b: Position) -> float:
    return WGS84.Inverse(a.latitude, a.longitude, b.latitude, b.longitude, Geodesic.DISTANCE)["s12"]


def destination(origin: Position, bearing: Quantity, distance: Quantity) -> Position:
    """The position reached by following a geodesic from origin."""
    result = WGS84.Direct(
        origin.latitude,
        origin.longitude,
        bearing.to("deg").value,
        distance.to("m").value,
        Geodesic.LATITUDE | Geodesic.LONGITUDE | Geodesic.LONG_UNROLL,
    )
    return Position(_wrap_longitude(result["lon2"]), result["lat2"])


def interpolate(
    a: Position, b: Position, fraction: float, line: GeodesicLine | None = None
) -> Position:
    """The point a given fraction of the way along the geodesic from a to b.

    ``line`` is the geodesic from a to b (``WGS84.InverseLine``) when the caller
    already has it, as TrackPath does: working it out is most of the cost.
    """
    if fraction <= 0.0:
        return a
    if fraction >= 1.0:
        return b
    if line is None:
        line = _line(a, b)
    point = line.Position(fraction * line.s13, Geodesic.LATITUDE | Geodesic.LONGITUDE)
    return Position(_wrap_longitude(point["lon2"]), point["lat2"])


def _line(a: Position, b: Position) -> GeodesicLine:
    return WGS84.InverseLine(a.latitude, a.longitude, b.latitude, b.longitude)


def geodesic_points(a: Position, b: Position, segments: int) -> list[Position]:
    """Points along the geodesic from a to b, for drawing it on a projected map (SUB-03)."""
    if segments < 1:
        raise ValueError("segments must be at least 1")
    line = WGS84.InverseLine(a.latitude, a.longitude, b.latitude, b.longitude)
    points = []
    for i in range(segments + 1):
        point = line.Position(
            line.s13 * i / segments, Geodesic.LATITUDE | Geodesic.LONGITUDE | Geodesic.LONG_UNROLL
        )
        points.append(Position(point["lon2"], point["lat2"]))
    return points


# Sides of the polygon that stands in for a circle or an ellipse in a plot file,
# so that other GeoJSON tools see the area (GeoJSON has no curves). Debrief
# draws circles and ellipses from their centre and size, not from this polygon.
CURVE_SIDES = 72


def circle_ring(centre: Position, radius: Quantity, sides: int = CURVE_SIDES) -> list[Position]:
    """A closed ring of positions at one geodesic range from centre, clockwise from north.

    The first position is due north of the centre and is repeated at the end,
    as a GeoJSON polygon ring requires.
    """
    if radius.to("m").value <= 0:
        raise ValueError("a circle's radius must be more than zero")
    return _ring(centre, lambda t: (t, radius.to("m").value), sides)


def ellipse_ring(
    centre: Position,
    semi_major: Quantity,
    semi_minor: Quantity,
    orientation: Quantity,
    sides: int = CURVE_SIDES,
) -> list[Position]:
    """A closed ring approximating an ellipse about centre.

    Its longer axis points along orientation (true, clockwise from north).
    Each position is at parametric angle t: (a cos t, b sin t) in the ellipse's
    own axes, found by following the geodesic from the centre at that point's
    bearing for that point's distance. As legacy Debrief drew them, so an
    imported ellipse keeps its shape. The first position is at the end of the
    longer axis, and is repeated at the end.
    """
    a, b = semi_major.to("m").value, semi_minor.to("m").value
    if not 0 < b <= a:
        raise ValueError(
            "an ellipse's semi-minor axis must be more than zero and at most its semi-major axis"
        )
    turn = orientation.to("deg").value

    def at(t_deg: float) -> tuple[float, float]:
        t = math.radians(t_deg)
        x, y = a * math.cos(t), b * math.sin(t)
        return (turn + math.degrees(math.atan2(y, x))) % 360.0, math.hypot(x, y)

    return _ring(centre, at, sides)


def _ring(centre: Position, at, sides: int) -> list[Position]:
    if sides < 3:
        raise ValueError("a ring needs at least three sides")
    ring = []
    for i in range(sides):
        bearing, distance = at(360.0 * i / sides)
        result = WGS84.Direct(
            centre.latitude,
            centre.longitude,
            bearing,
            distance,
            Geodesic.LATITUDE | Geodesic.LONGITUDE,
        )
        ring.append(Position(result["lon2"], result["lat2"]))
    ring.append(ring[0])
    return ring


def _wrap_longitude(longitude: float) -> float:
    wrapped = math.fmod(longitude + 180.0, 360.0)
    if wrapped < 0:
        wrapped += 360.0
    return wrapped - 180.0


class _Parsed(Sequence):
    """A plot's fix times or positions, each read from its text or coordinates only when
    first asked for: a track of 200,000 fixes is searched by bisection, so finding where a
    cut falls reads a few dozen of them, not every one (3 s on such a track before)."""

    def __init__(self, raw: Sequence, read) -> None:
        self._raw = raw
        self._read = read
        self._done: dict[int, object] = {}

    def __len__(self) -> int:
        return len(self._raw)

    def __getitem__(self, index):  # type: ignore[override]
        if isinstance(index, slice):
            return [self[i] for i in range(*index.indices(len(self)))]
        if index < 0:
            index += len(self._raw)
        found = self._done.get(index)
        if found is None:
            found = self._done[index] = self._read(self._raw[index])
        return found


class TrackPath:
    """A track's positions over time, interpolated along geodesics between fixes."""

    def __init__(
        self,
        times_ms: Sequence[int],
        positions: Sequence[Position],
        courses: Sequence[float] | None = None,
        *,
        checked: bool = False,
    ):
        if len(times_ms) != len(positions):
            raise ValueError("times and positions differ in length")
        if not len(times_ms):
            raise ValueError("a track needs at least one position")
        if courses is not None and len(courses) != len(times_ms):
            raise ValueError("courses and times differ in length")
        if not checked and any(a > b for a, b in zip(times_ms, times_ms[1:], strict=False)):
            raise ValueError("times are not in order")
        self.times_ms = times_ms if checked else list(times_ms)
        self.positions = positions if checked else list(positions)
        # The course recorded at each fix, degrees true, where the track has them: what
        # legacy Debrief told port and starboard by (reported_course_at).
        self.courses = courses
        # The geodesic between each pair of fixes, worked out once: closest approach
        # asks for many positions along the same few legs.
        self._lines: dict[int, GeodesicLine] = {}

    @classmethod
    def from_feature(cls, feature: schema.TrackFeature) -> TrackPath:
        """A plot's track: its times, positions and recorded courses, all read."""
        lazy = cls.lazy_from_feature(feature)
        return cls(list(lazy.times_ms), list(lazy.positions), lazy.courses, checked=True)

    @classmethod
    def lazy_from_feature(cls, feature: schema.TrackFeature) -> TrackPath:
        """A plot's track, its times and positions read as they are asked for (the plot
        was checked when read: its times are in order): where a few cuts are placed on a
        track of 200,000 fixes, a few dozen are read, not all."""
        props = feature.properties
        courses = None
        if props.courses is not None:
            radians = str(props.courses.unit) == "rad"
            courses = [math.degrees(c) if radians else c for c in props.courses.values]
        return cls(
            _Parsed(props.times, parse_utc),
            _Parsed(feature.geometry.coordinates, lambda c: Position(c[0], c[1])),
            courses,
            checked=True,
        )

    @property
    def start_ms(self) -> int:
        return self.times_ms[0]

    @property
    def end_ms(self) -> int:
        return self.times_ms[-1]

    def position_at(self, time_ms: int) -> Position | None:
        """Position at a time, or None outside the track's time span."""
        leg = self.leg_at(time_ms)
        if leg is None:
            return None
        index, fraction = leg
        if index >= len(self.times_ms) - 1:
            return self.positions[-1]
        if fraction >= 1.0:
            return self.positions[index + 1]
        a, b = self.positions[index], self.positions[index + 1]
        return interpolate(a, b, fraction, self.line(index))

    def leg_at(self, time_ms: int) -> tuple[int, float] | None:
        """The fix a time follows and how far it is towards the next, by time; None outside
        the track's span. At the last fix, its index and 0. Between two fixes at one time,
        the second (fraction 1)."""
        if time_ms < self.start_ms or time_ms > self.end_ms:
            return None
        index = bisect_right(self.times_ms, time_ms) - 1
        if index >= len(self.times_ms) - 1:
            return len(self.times_ms) - 1, 0.0
        t0, t1 = self.times_ms[index], self.times_ms[index + 1]
        if t1 == t0:
            return index, 1.0
        return index, (time_ms - t0) / (t1 - t0)

    def course_at(self, time_ms: int) -> float | None:
        """The track's direction of travel at a time, degrees true, as the map's pointAt
        gives it (vscode/webview/geodesic.ts): along the geodesic between the fixes either
        side, the course at that point of it; at a fix, the course of the leg leaving it
        (arriving, at the last fix); where the track did not move, the nearest leg before
        it that did. None outside the track's span, and for a track that never moved.
        A cut's port and starboard are told by it (CAP-22), held to
        schemas/vectors/sensor-cuts.json."""
        times = self.times_ms
        if not len(times) or time_ms < times[0] or time_ms > times[-1] or len(times) == 1:
            return None
        low, high = 0, len(times) - 1
        while high - low > 1:  # the later of fixes sharing a time, as pointAt brackets
            middle = (low + high) >> 1
            if times[middle] <= time_ms:
                low = middle
            else:
                high = middle
        span = times[high] - times[low]
        fraction = (time_ms - times[low]) / span if span > 0 else 1.0
        if fraction <= 0 or fraction >= 1:
            fix = low if fraction <= 0 else high
            leaving = self._leg_course(fix, fix + 1) if fix + 1 < len(times) else None
            return leaving if leaving is not None else self._course_before(fix)
        line = self.line(low)
        if line.s13 <= 0.01:
            return self._course_before(low)
        point = line.Position(fraction * line.s13, Geodesic.AZIMUTH)
        return normalise_bearing(point["azi2"])

    def reported_course_at(self, time_ms: int) -> float | None:
        """The course port and starboard are told by, as legacy Debrief's isBearingToPort
        took it: the course recorded at the first fix at or after the time (the host's
        getNearestTo, not interpolated); where the track records no courses, its
        direction of travel there (course_at). None outside the track's span."""
        times = self.times_ms
        if not len(times) or time_ms < times[0] or time_ms > times[-1]:
            return None
        if self.courses is not None:
            return normalise_bearing(self.courses[bisect_left(times, time_ms)])
        return self.course_at(time_ms)

    def _leg_course(self, i: int, j: int) -> float | None:
        a, b = self.positions[i], self.positions[j]
        g = WGS84.Inverse(a.latitude, a.longitude, b.latitude, b.longitude, _INVERSE)
        return normalise_bearing(g["azi1"]) if g["s12"] > 0.01 else None

    def _course_before(self, end: int) -> float | None:
        for k in range(end, 0, -1):
            course = self._leg_course(k - 1, k)
            if course is not None:
                return course
        return None

    def line(self, index: int) -> GeodesicLine:
        """The geodesic from fix index to the next, worked out once."""
        line = self._lines.get(index)
        if line is None:
            line = self._lines[index] = _line(self.positions[index], self.positions[index + 1])
        return line


@dataclass(frozen=True, slots=True)
class ClosestApproach:
    time_ms: int
    range: Quantity
    position_a: Position
    position_b: Position


_GOLDEN = (math.sqrt(5.0) - 1.0) / 2.0


def closest_approach(
    a: TrackPath, b: TrackPath, start_ms: int | None = None, end_ms: int | None = None
) -> ClosestApproach | None:
    """Closest point of approach between two tracks over their common time span.

    Between consecutive fixes of either track both platforms move along
    geodesics at constant rate, so range varies smoothly. Each such interval
    is searched by golden-section minimisation to millisecond resolution.
    Returns None if the tracks never overlap in time.
    """
    lo = max(a.start_ms, b.start_ms, start_ms if start_ms is not None else -math.inf)
    hi = min(a.end_ms, b.end_ms, end_ms if end_ms is not None else math.inf)
    if lo > hi:
        return None
    lo, hi = int(lo), int(hi)
    breaks = sorted({lo, hi, *(t for t in a.times_ms + b.times_ms if lo < t < hi)})

    ranges: dict[int, float] = {}

    def range_at(t: int) -> float:
        if t not in ranges:
            ranges[t] = _range_m(a.position_at(t), b.position_at(t))
        return ranges[t]

    best_t, best_r = lo, range_at(lo)
    for t0, t1 in zip(breaks, breaks[1:], strict=False):
        t, r = _minimise(range_at, t0, t1)
        if r < best_r:
            best_t, best_r = t, r
    if range_at(hi) < best_r:
        best_t, best_r = hi, range_at(hi)
    return ClosestApproach(
        best_t, Quantity(best_r, "m"), a.position_at(best_t), b.position_at(best_t)
    )


def _minimise(f, lo: int, hi: int) -> tuple[int, float]:
    """Golden-section search for a minimum on integer milliseconds in [lo, hi]."""
    a, b = float(lo), float(hi)
    c, d = b - _GOLDEN * (b - a), a + _GOLDEN * (b - a)
    fc, fd = f(round(c)), f(round(d))
    while b - a > 2.0:
        if fc <= fd:
            b, d, fd = d, c, fc
            c = b - _GOLDEN * (b - a)
            fc = f(round(c))
        else:
            a, c, fc = c, d, fd
            d = a + _GOLDEN * (b - a)
            fd = f(round(d))
    candidates = {lo, hi, *range(int(math.floor(a)), int(math.ceil(b)) + 1)}
    best = min((t for t in candidates if lo <= t <= hi), key=f)
    return best, f(best)
